# BIKE RENTAL ANALYSIS
Welcome to my analysis. This Analysis about bicycle rental in a country in 2011 and 2012. This project have 2 main data. 
You can see the process Analysis in Notebook.ipynb and dashboard in app.py.

## Setup

1. Clone the repository:
    ```bash
    https://github.com/gdepradd/bikeAnalysis.git
    ```

2. Install the required dependencies:
    ```bash
    pip install -r dashboard/requirements.txt
    ```

3. Run the application locally:
    ```bash
    streamlit run dashboard/app.py
    ```
